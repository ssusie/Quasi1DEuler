function  [u] = inputFileT2(t)

u = exp(-t);

end