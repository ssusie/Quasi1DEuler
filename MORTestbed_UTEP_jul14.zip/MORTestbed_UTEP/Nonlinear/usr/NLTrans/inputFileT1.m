function  [u] = inputFileT1(t)

u = (cos(2*pi*t/10) + 1)/2;

end