function  [u2] = inputFileO1(t)
%u2 = 4.5^2 -> the left DBC is u = 4.5
u2 = 4.5^2;

end