function  [u2] = inputFileT3(t)
%u2 = 9^2 -> the left DBC is u = 9
u2 = 9^2;

end