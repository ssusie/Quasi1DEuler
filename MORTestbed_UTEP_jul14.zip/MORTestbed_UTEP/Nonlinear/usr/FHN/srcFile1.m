function  [src] = srcFile1(x)

c = 0.05;
src =  c*ones(length(x),1);

end