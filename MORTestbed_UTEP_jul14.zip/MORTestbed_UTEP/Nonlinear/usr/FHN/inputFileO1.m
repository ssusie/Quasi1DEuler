function  [u] = inputFileO1(t)

u = 10/(t+1);
% u = [10/(t+1);sin(t)];

end