#ifndef __CONVERTSTRUCTURES
#define __CONVERTSTRUCTURES

//void mxMesh(mxArray const* mlmesh, mesh &msh);
//void mxPhysics(mxArray const* mlphys, physics &phys);
//void mxIntegrate(mxArray const* mlquad, integration &quad);
//void mxDBC(mxArray const* mldbc, DirichletBCs &dbc);

#endif
