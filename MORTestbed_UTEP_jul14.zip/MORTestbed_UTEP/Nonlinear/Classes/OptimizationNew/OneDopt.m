classdef OneDopt < handle
    
    properties
        optprob;
    end
    
    methods
        function  [obj] = OneDopt(optobj)
            obj.optprob=optobj;
        end
        
        function  [soln] = parabolicinterp(obj)
            
        end
    end
    
end