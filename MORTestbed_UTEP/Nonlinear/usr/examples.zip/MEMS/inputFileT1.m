function  [u] = inputFileT1(t)

% u = (5.5*exp(-50*t*1000))^2;
% u = (7*cos(t*(pi/3)*1e5)).^2;
% u = (7*cos(t*4*pi*1000))^2;
u = 9^2;
% u = 5.5^2;

end