function  [u] = inputFileT2(t)

u = 50000*(t^3)*exp(-15*t);
% u = [50000*(t^3)*exp(-15*t);sin(t)];

end