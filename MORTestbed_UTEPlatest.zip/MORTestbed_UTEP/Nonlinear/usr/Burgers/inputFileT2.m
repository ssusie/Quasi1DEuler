function  [u2] = inputFileT2(t)
%u2 = 6^2 -> the left DBC is u = 6
u2 = 6^2;

end