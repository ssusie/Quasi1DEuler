function  [u2] = inputFileT1(t)
%u2 = 4^2 -> the left DBC is u = 5
u2 = 4^2;

end