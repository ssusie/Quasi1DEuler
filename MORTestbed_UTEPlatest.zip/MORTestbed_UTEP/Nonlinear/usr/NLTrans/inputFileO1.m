function  [u] = inputFileO1(t)

u = 1 - t/50;

end