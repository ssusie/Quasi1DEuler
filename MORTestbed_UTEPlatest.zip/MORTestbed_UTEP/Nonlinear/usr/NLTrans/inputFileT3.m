function  [u] = inputFileT3(t)

u = 1;

end