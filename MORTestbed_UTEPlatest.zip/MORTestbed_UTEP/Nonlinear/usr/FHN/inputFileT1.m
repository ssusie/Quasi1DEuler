function  [u] = inputFileT1(t)

u = 50000*(t^3)*exp(-15*t);
% u = [50000*(t^3)*exp(-15*t);0];

end